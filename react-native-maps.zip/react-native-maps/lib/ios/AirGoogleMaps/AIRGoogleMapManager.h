//
//  AIRGoogleMapManager.h
//  AirMaps
//
//  Created by Gil Birman on 9/1/16.
//

#import <React/RCTViewManager.h>

@interface AIRGoogleMapManager : RCTViewManager

@end
