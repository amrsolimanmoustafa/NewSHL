//
//  AIRGoogleMapCircleManager.h
//
//  Created by Nick Italiano on 10/24/16.
//

#import <React/RCTViewManager.h>

@interface AIRGoogleMapCircleManager : RCTViewManager

@end
