//
//  AIRGoogleMapPolylgoneManager.h
//
//  Created by Nick Italiano on 10/22/16.
//

#import <React/RCTViewManager.h>

@interface AIRGoogleMapPolygonManager : RCTViewManager

@end
