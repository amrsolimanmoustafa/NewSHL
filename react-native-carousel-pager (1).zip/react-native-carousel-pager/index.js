import CarouselPager from './CarouselPager';

export default CarouselPager;
